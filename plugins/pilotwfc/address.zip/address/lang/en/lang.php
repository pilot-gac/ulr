<?php return [
    'plugin' => [
        'name' => 'address',
        'description' => ''
    ]
];